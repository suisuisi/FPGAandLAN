1. Make sure you configure the below flags based on 
   ethernet mode (1000BASE-X or SGMII) in Si5324.c patch file:
   
   For example :
   SGMII mode :
   
   #define XPAR_GIGE_PCS_PMA_SGMII_CORE_PRESENT 1
   #define XPAR_GIGE_PCS_PMA_1000BASEX_CORE_PRESENT 0
   
   1000BASE-X mode
   
   #define XPAR_GIGE_PCS_PMA_SGMII_CORE_PRESENT 0
   #define XPAR_GIGE_PCS_PMA_1000BASEX_CORE_PRESENT 1